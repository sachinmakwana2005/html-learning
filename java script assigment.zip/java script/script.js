        function seqre(){
            let val=document.getElementById("value").value;
            let sequre = val*val;
            alert(sequre)
        }
        function cube(){
            let val=document.getElementById("value").value;
            let cube = val*val*val;
            alert(cube);
        }